import"./modulepreload-polyfill.c7c6310f.js";chrome.devtools.panels.create("cms_tool",null,"index.html");
